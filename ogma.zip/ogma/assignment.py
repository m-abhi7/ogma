import yfinance as yf
import json
import sqlite3

from flask import request, Flask, render_template, flash, jsonify, session,  redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required, JWTManager
from flask_login import LoginManager, login_user, UserMixin, login_required, current_user

secret_key = "\xbf\x1f\xc4*\xecE\x87B\x89\x8d_\xd6\x84;>\xc0U\x82\xad\xdd\xe5.s!"
login_manager = LoginManager()

app = Flask(__name__)
app.secret_key = secret_key

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ogma.db'
app.config["JWT_SECRET_KEY"] = secret_key 

db = SQLAlchemy(app)
jwt = JWTManager(app)

login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(username):
	#return User.objects(id=user_id).first()
	return User.query.filter_by(username=username).first()


#create User database
class User(UserMixin, db.Model):
	username = db.Column(db.String(32), unique=True, primary_key=True)
	password = db.Column(db.String(32))
	roles = db.Column(db.String(80))	
	def to_json(self):        
		return {"username": self.username}

	def is_authenticated(self):
		return True

	def is_active(self):   
		return True           

	def is_anonymous(self):
		return False          

	def get_id(self):
		return (self.username)

db.create_all()
print("Created User DB")

@app.route('/', methods=['GET', 'POST'])
def homePage():
	return render_template("login.html")
	
@app.route('/login/', methods=['GET', 'POST'])
def login():
	conn = sqlite3.connect('ogma.db')
	#only POST methods allowed
	if request.method == 'POST':
		username = request.form['loginEmail']
		password = request.form['loginPassword']
		user = User.query.filter_by(username=username).first()
		if not user or not check_password_hash(user.password, password):
			conn.commit()
			return 'Please check your login details and try again.'
		else:
			access_token = create_access_token(identity=username)
			conn.commit()
			if username == "admin@admin":
				return redirect(url_for('adminPage'))
			else:
				login_user(user)
				return redirect(url_for('userPage'))

	#if not POST method
	else:
		return "Only POST methods allowed"
	
@app.route('/admin/', methods=['GET', 'POST'])
@login_required
def adminPage():
	if request.method == 'GET':
		return render_template("admin.html")
	if request.method == 'POST':
		newUsername = request.form['newUsername']
		newPassword = request.form['newPassword']
		userInDB = User.query.filter_by(username=newUsername).first()
		if userInDB is None:
			new_user = User(username=newUsername, password=generate_password_hash(newPassword))
			db.session.add(new_user)
			db.session.commit()
			return 'New user {} added.'.format(newUsername)
		else:
			return "User already exists"

@app.route('/user/', methods=['GET', 'POST'])
@login_required
def userPage():
	if request.method == 'GET':
		return render_template("stock.html", username=current_user.username)
	if request.method == 'POST':
		stock = request.form['stock']
		stock = yf.Ticker(stock)
		#print(stock.info['previousClose'])
		#return str(stock.info['previousClose'])
		return render_template("stock.html", username=current_user.username, stock = str(stock.info['previousClose']))

@app.route('/register/', methods=['GET', 'POST'])
def register():
	conn = sqlite3.connect('ogma.db')
	if request.method == 'POST':
		username = request.form['regEmail']
		password = request.form['regPassword']
		userInDB = User.query.filter_by(username=username).first()
		print(username, password)
		if userInDB is None:
			new_user = User(username=username, password=generate_password_hash(password))
			db.session.add(new_user)
			db.session.commit()
			return 'New user {} added.'.format(username)
		else:
			db.session.commit()
			conn.commit()
			return 'User {} is already registered. Please try another username'.format(username)
	#if not POST method
	else:
		return "Only POST methods allowed"

if __name__ == '__main__':
   app.run(debug = True)